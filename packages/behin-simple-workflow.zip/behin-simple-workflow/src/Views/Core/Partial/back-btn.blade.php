<div class="card">
    <div class="card-header">
        <a href="javascript:history.back()" class="btn btn-outline-primary float-left">
            <i class="fa fa-arrow-left"></i> {{ trans('fields.Back') }}
        </a>
    </div>
</div>